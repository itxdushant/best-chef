<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('main-sidebar')) : ?>

	<div class="sidebar-widget">
	
		<?php get_search_form(); ?>
		
	</div> <!-- end sidebar-widget -->
	
<?php endif; ?>