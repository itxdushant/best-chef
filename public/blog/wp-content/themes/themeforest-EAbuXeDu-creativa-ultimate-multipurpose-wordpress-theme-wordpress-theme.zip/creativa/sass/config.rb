# Set this to the root of your project when deployed:
http_path = "/"
css_dir = ""
sass_dir = "sass"
images_dir = "img"
javascripts_dir = "js"
fonts_dir = "fonts"
Encoding.default_external = "UTF-8"

output_style = :expanded
environment = :production

relative_assets = true