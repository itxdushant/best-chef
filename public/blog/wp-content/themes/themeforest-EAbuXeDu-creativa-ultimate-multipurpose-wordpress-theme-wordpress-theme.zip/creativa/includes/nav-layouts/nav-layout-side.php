<?php 
$creativa_options = creativa_get_options();

$nav_sep_class = 'no-nav-separators';
if ($creativa_options['opt-nav-separators'] == 1) {
  $nav_sep_class = 'with-nav-separators';
}

$nav_search_icon = $creativa_options['opt-nav-search'];
$nav_cart_icon = $creativa_options['opt-woo-shop-nav-icon'];

$nav_icons_class = 'no-nav-icons';
if ($nav_search_icon == 1 || $nav_cart_icon == 1) {
  $icons_style = $creativa_options['opt-nav-icons-style'];

  $nav_icons_class = 'with-nav-icons ';

  if ($icons_style == 1) {
    $nav_icons_class .= 'nav-icons--text';
  }
  elseif ($icons_style == 2) {
    $nav_icons_class .= 'nav-icons--small';
  }
  elseif ($icons_style == 3) {
    $nav_icons_class .= 'nav-icons--large';
  }
}
?>

<header>

  <?php 
    if (function_exists('creativa_topbar')) {
      creativa_topbar();
    }
  ?>
  
  <div class="nav-side <?php echo esc_attr($nav_sep_class) .' '. esc_attr($nav_icons_class) ?>">
    <div class="nav-side__mobile-menu">
      <i class="icon_menu"></i><?php esc_html_e('Menu', 'creativa') ?>
    </div>
    <?php if ($creativa_options['opt-navigation-side-overlay'] == 1) { ?>
      <div class="nav-side__overlay"></div>
    <?php } ?>
    <div class="nav-side__wrapper">


      <!-- logotype container -->
      <div class="nav-side__logo">
        <a href="<?php echo esc_url(home_url( '/' )); ?>">
          <?php 
          if ( isset($creativa_options['opt-logo']['url']) && !empty($creativa_options['opt-logo']['url']) ) { ?>
            <img src="<?php echo esc_url($creativa_options['opt-logo']['url']) ?>" alt="<?php bloginfo('name'); ?>">
          <?php } else { bloginfo('name'); } ?>
        </a>
      </div><!-- logotype container end -->
      <?php if ( has_nav_menu( 'main-nav' ) ) { ?>
        <?php 
          $creativa_meta_custom_menu = $creativa_options['opt-meta-custom-menu'];
          if ($creativa_meta_custom_menu) {
            $creativa_menu_id = $creativa_meta_custom_menu;
          } else {
            $creativa_menu_id = '';
          }
        ?>
        <nav class="sidebar-nav">
          <?php wp_nav_menu(
              array(
                'theme_location' => 'main-nav',
                'menu'            => $creativa_menu_id,
                'link_before'     => '<span>',
                'link_after'      => '</span>',
              )
            );
          ?>
        </nav>
      <?php
      } else { ?>
        <div class="sidebar-nav"><ul><li><a href="<?php echo admin_url('nav-menus.php'); ?>"><div class="menu-a-inner"><span>
          <?php esc_html_e('Assign menu to this area', 'creativa' ) ?> 
        </span></div></a></li></ul></div> 
      <?php } ?>

      <div class="nav-side__bottom--wrap">
        <?php creativa_navicons(); ?>
      </div>

    </div>
  </div>
</header>